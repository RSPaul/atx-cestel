

</div> 

		<div class="footer-section footer-menu-grid" style="text-align:center;padding:10px 0px 50px 0px;">			
			<div class="footer-widget footer-social-grid">
				<!-- social icons -->
				<div class="widget-social-icon text-center">
					<ul style="padding:0px;">					
						<li style="display: inline-block;margin: 0 10px;position: relative;list-style:none;">
							<a href="#" style="font-weight: 600;color:#328079;text-decoration:none;">
								<img alt="" src="https://localchef.smallbizplace.com/public/img/facebook.png" style="max-width:35px;" />
							</a>
						</li>
						<li style="display: inline-block;margin: 0 10px;position: relative;list-style:none;">
							<a href="#" style="font-weight: 600;color:#328079;text-decoration:none;">
								<img alt="" src="https://localchef.smallbizplace.com/public/img/instagram.png" style="max-width:35px;" />
							</a>
						</li>						
					</ul>
				</div>
				<!-- //social icons -->
			</div>
		
			<p class="copyright" style="font-size:13px;float:left;width:100%;text-align:center;">© Copyrights 2019 Best Local Chef All rights reserved.</p>
		</div>  
	</div>
 </body>
</html>