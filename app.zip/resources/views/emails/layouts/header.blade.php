<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>
<style type="text/css">

.im {
    color: #500050;
    font-size: 18px;
}
p
{
	font-size: 18px;
}
.footer-section img {
	width:80px;
}

.footer-menu-grid ul li {
	display: inline-block;
	margin: 0 10px;
	position: relative;
}

.footer-menu-grid ul li a {
	font-weight: 600;
	color:#328079;
	text-decoration:none;
}

.widget-social-icon ul,
.footer-menu-grid ul {
	padding:0px;
}

.footer-menu-grid ul li {
	display: inline-block;
	margin: 0 2px;
}

.widget-social-icon ul img {
	max-width:35px;
}

.copyright {
	font-size:13px;
}

</style>
<body style="margin:0px;background:#f1f1f1;padding:40px 0  40px 0;">
	<div class="container">
		<div class="header-section" style="text-align:center;background:#000;width:80%;margin:0px auto;">
			<img alt="" src="https://localchef.smallbizplace.com/public/img/logo2.png" style="width:150px;padding:12px 0;" />			
		</div>
		 
		<div class="body-section" style="width:70%;	margin:0px auto;box-shadow:1px 1px 10px rgba(0, 0, 0, 0.1);background:#fff;padding:20px;">