<?php $__env->startSection('content'); ?>

<!-- banner -->
<section class="inner-page-banner login-inner-banner">
    <div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="page-title-wrap text-center">
					<h1 class="page-title-heading">Login</h1>
					<p class="page-sub-title">Submit Login Details</p>
				</div>
			</div>
		</div>
    </div>
</section>
<!-- //banner -->

<div class="content-wrap">
<section class="login-main-section">
	<div class="container">
		<!-- login  -->
		<div class="row">
			<div class="col-md-8 col-lg-6 offset-lg-3 offset-md-2">
				<div class="form-border-md">
				<form class="login-form-grid"  method="POST" action="<?php echo e(route('login')); ?>">
						<?php echo csrf_field(); ?>
					<div class="form-group">
						<label class="col-form-label">Email</label>
						<input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
						<?php if($errors->has('email')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('email')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<div class="form-group">
						<label class="col-form-label">Password</label>
						<input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
						<?php if($errors->has('password')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('password')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<button type="submit" class="btn btn-default more-btn btn-block">Login</button>
					<div class="row sub-w3l mt-3 mb-lg-3">
						<div class="col-sm-6 sub-w3layouts_hub">
							<input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
							<label for="brand1">
								<span></span>Remember me?</label>
						</div>
						<div class="col-sm-6 forgot-w3l text-sm-right">
							<?php if(Route::has('password.request')): ?>
								<a class="text-li text-style-w3ls" href="<?php echo e(route('password.request')); ?>">
									<?php echo e(__('Forgot Your Password?')); ?>

								</a>
							<?php endif; ?>
						</div>
					</div>

					<p class="text-center dont-do">Don't have an account?
						<a href="/register" class="font-weight-bold">
							Register Now</a>
					</p>
				</form>
				</div>
			</div>
		</div>
		<!-- //login -->
	</div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atx-cestel\resources\views/auth/login.blade.php ENDPATH**/ ?>